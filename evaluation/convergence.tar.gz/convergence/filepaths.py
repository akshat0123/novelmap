TITLES = './data/base/books.txt'
SHELVES = './data/base/book_shelves.json'

DELIM = './data/base/books_delimiter_data.txt'
RAW = './data/raw'

DICT = './data/dumps/book_dictionary.dict'
CORP = './data/dumps/book_corpus.dict'
TOKEN = './data/dumps/token_dump.p'

